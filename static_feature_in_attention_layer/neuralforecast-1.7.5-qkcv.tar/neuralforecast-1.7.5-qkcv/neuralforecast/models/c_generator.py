__all__ = ['C_Generator']

import math
import torch
import torch.nn as nn
from torch import Tensor
from torch.nn import LayerNorm
import pandas as pd
import torch.nn.functional as F
from typing import Tuple, Optional
from .tft import GRN, VariableSelectionNetwork


class TFTEmbedding_qkcv(nn.Module):
    def __init__(
        self, hidden_size, stat_input_size
    ):
        super().__init__()

        self.hidden_size = hidden_size

        self.stat_input_size = stat_input_size

        # Instantiate Continuous Embeddings if size is not None
        for attr, size in [
            ("stat_exog_embedding", stat_input_size),
        ]:
            if size:
                vectors = nn.Parameter(torch.Tensor(size, hidden_size))
                bias = nn.Parameter(torch.zeros(size, hidden_size))
                torch.nn.init.xavier_normal_(vectors)
                setattr(self, attr + "_vectors", vectors)
                setattr(self, attr + "_bias", bias)
            else:
                setattr(self, attr + "_vectors", None)
                setattr(self, attr + "_bias", None)

    def _apply_embedding(
        self,
        cont: Optional[Tensor],
        cont_emb: Tensor,
        cont_bias: Tensor,
    ):
        if cont is not None:
            # the line below is equivalent to following einsums
            # e_cont = torch.einsum('btf,fh->bthf', cont, cont_emb)
            # e_cont = torch.einsum('bf,fh->bhf', cont, cont_emb)
            e_cont = torch.mul(cont.unsqueeze(-1), cont_emb)
            e_cont = e_cont + cont_bias
            return e_cont

        return None

    def forward(self, stat_exog=None):
        # temporal/static categorical/continuous known/observed input
        # tries to get input, if fails returns None

        # Static inputs are expected to be equal for all timesteps
        # For memory efficiency there is no assert statement
        stat_exog = stat_exog[:, :] if stat_exog is not None else None

        s_inp = self._apply_embedding(
            cont=stat_exog,
            cont_emb=self.stat_exog_embedding_vectors,
            cont_bias=self.stat_exog_embedding_bias,
        )

        return s_inp
    

class StaticCovariateEncoder(nn.Module):
    def __init__(self, hidden_size, num_static_vars, dropout, lstm_layer=1):
        super().__init__()
        self.vsn = VariableSelectionNetwork(
            hidden_size=hidden_size, num_inputs=num_static_vars, dropout=dropout
        )
        self.context_grn = GRN(input_size=hidden_size, hidden_size=hidden_size, dropout=dropout)

    def forward(self, x: Tensor) -> Tensor:
        variable_ctx, sparse_weights = self.vsn(x)

        # Context vectors:
        # variable selection context
        # enrichment context
        # state_c context
        # state_h context
        # cs, ce, ch, cc, ch1, cc1 
        x = self.context_grn(variable_ctx)

        return x # ca

class C_Generator(nn.Module):
    def __init__(self, hidden_size, stat_exog_size, dropout=0.1):
        super().__init__()

        self.embedding = TFTEmbedding_qkcv(
            hidden_size=hidden_size,
            stat_input_size=stat_exog_size,
        )

        if stat_exog_size > 0:
            self.static_encoder = StaticCovariateEncoder(
                hidden_size=hidden_size,
                num_static_vars=stat_exog_size,
                dropout=dropout, 
            )

    def forward(self, stat_exog):
        # stat_exog = windows_batch["stat_exog"]

        s_inp = self.embedding(
            stat_exog=stat_exog,
        )

        print(f'[C_Generator] stat_exog.shape: {stat_exog.shape}, stat_exog: {stat_exog}')

        print(f'[C_Generator] s_inp.shape: {s_inp.shape}, s_inp: {s_inp}')

        # -------------------------------- Inputs ------------------------------#
        # Static context
        if s_inp is not None:
            x = self.static_encoder(s_inp)

        # Use multi-layer perceptron (mlp) to embed stat_exog into vector x
        # x = nn.Sequential(
        #     nn.Linear(x.size(-1), self.embedding.hidden_size),
        #     nn.ReLU(),
        #     nn.Linear(self.embedding.hidden_size, self.embedding.hidden_size)
        # )(x)

        return x

